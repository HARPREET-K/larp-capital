<?php
/**
 * Map For Shop Top Five
 *
 * @package H-Code
 */
?>
<?php
/*-----------------------------------------------------------------------------------*/
/* Shop Top Five Block */
/*-----------------------------------------------------------------------------------*/

vc_map( array(
  'name' => __('Special Product Block', 'hcode-addons'),
  'description' => __( 'Place a special product block', 'hcode-addons' ),  
  'icon' => 'h-code-shortcode-icon fas fa-th-large',
  'base' => 'hcode_shop_top_five',
  'category' => 'H-Code',
  'params' => array(
  	array(
      'type' => 'responsive_font_settings',
      'param_name' => 'hcode_special_product_title_font_settings',
      'heading' => esc_html__( 'Font Settings For Special Product Title', 'hcode-addons' ),
      'hide_font_settings_element_lg' => array('text-align'),
      'hide_font_settings_element_md' => array('text-align'),
      'hide_font_settings_element_sm' => array('text-align'),
      'hide_font_settings_element_xs' => array('text-align'),
      'group' => 'Font & Color Settings',
    ),
    array(
      'type' => 'colorpicker',
      'class' => '',
      'heading' => __( 'Special Product Title Color', 'hcode-addons' ),
      'param_name' => 'hcode_special_product_title_color',
      'description' => __( 'Choose Product Title Color', 'hcode-addons' ),
      'group' => 'Font & Color Settings',
    ),
    array(
      'type' => 'colorpicker',
      'class' => '',
      'heading' => __( 'Special Product Title Hover Color', 'hcode-addons' ),
      'param_name' => 'hcode_special_product_title_hover_color',
      'description' => __( 'Choose Product Title Hover Color', 'hcode-addons' ),
      'group' => 'Font & Color Settings',
    ),
    array(
      'type' => 'responsive_font_settings',
      'param_name' => 'hcode_special_product_price_font_settings',
      'heading' => esc_html__( 'Font Settings For Special Product Price', 'hcode-addons' ),
      'hide_font_settings_element_lg' => array('text-align','font-transform'),
      'hide_font_settings_element_md' => array('text-align','font-transform'),
      'hide_font_settings_element_sm' => array('text-align','font-transform'),
      'hide_font_settings_element_xs' => array('text-align','font-transform'),
      'group' => 'Font & Color Settings',
    ),
    array(
      'type' => 'colorpicker',
      'class' => '',
      'heading' => __( 'Product Price Color', 'hcode-addons' ),
      'param_name' => 'hcode_special_product_price_color',
      'description' => __( 'Choose Special Product Price Color', 'hcode-addons' ),
      'group' => 'Font & Color Settings',
    ),
    array(
      'type'        => 'hcode_button_settings',
      'param_name'  => 'special_poduct_button_settings',
      'heading'     => esc_html__( 'Special Product Button Font Settings', 'hcode-addons' ),
      'group' => 'Font & Color Settings',
      'description' => __( 'You can easily set button text-transform, font-size, line-height, letter-spacing for all devices ', 'hcode-addons' ),
      'hide_font_settings_element' => array( 'text-align', 'icon-color', 'icon-hover-color' ),
    ),
    array(
      'type' => 'responsive_font_settings',
      'param_name' => 'hcode_feature_product_title_font_settings',
      'heading' => esc_html__( 'Font Settings For Feature Product Title', 'hcode-addons' ),
      'hide_font_settings_element_lg' => array('text-align'),
      'hide_font_settings_element_md' => array('text-align'),
      'hide_font_settings_element_sm' => array('text-align'),
      'hide_font_settings_element_xs' => array('text-align'),
      'group' => 'Feature Product Font & Color Settings',
    ),
    array(
      'type' => 'colorpicker',
      'class' => '',
      'heading' => __( 'Feature Product Title Color', 'hcode-addons' ),
      'param_name' => 'hcode_feature_product_title_color',
      'description' => __( 'Choose Feature Title Color', 'hcode-addons' ),
      'group' => 'Feature Product Font & Color Settings',
    ),
    array(
      'type' => 'colorpicker',
      'class' => '',
      'heading' => __( 'Feature Product Title Hover Color', 'hcode-addons' ),
      'param_name' => 'hcode_feature_product_title_hover_color',
      'description' => __( 'Choose Feature Title Hover Color', 'hcode-addons' ),
      'group' => 'Feature Product Font & Color Settings',
    ),
    array(
      'type' => 'responsive_font_settings',
      'param_name' => 'hcode_special_feature_price_font_settings',
      'heading' => esc_html__( 'Font Settings For Feature Product Price', 'hcode-addons' ),
      'hide_font_settings_element_lg' => array('text-align','font-transform'),
      'hide_font_settings_element_md' => array('text-align','font-transform'),
      'hide_font_settings_element_sm' => array('text-align','font-transform'),
      'hide_font_settings_element_xs' => array('text-align','font-transform'),
      'group' => 'Feature Product Font & Color Settings',
    ),
    array(
      'type' => 'colorpicker',
      'class' => '',
      'heading' => __( 'Feature Product Price Color', 'hcode-addons' ),
      'param_name' => 'hcode_feature_product_price_color',
      'description' => __( 'Choose Feature Product Price Color', 'hcode-addons' ),
      'group' => 'Feature Product Font & Color Settings',
    ),
    array(
      'type' => 'colorpicker',
      'class' => '',
      'heading' => __( 'Feature Product Content Color', 'hcode-addons' ),
      'param_name' => 'hcode_feature_product_content_color',
      'description' => __( 'Choose Feature Product Content Color', 'hcode-addons' ),
      'group' => 'Feature Product Font & Color Settings',
    ),
    array(
      'type'        => 'hcode_button_settings',
      'param_name'  => 'special_feature_button_settings',
      'heading'     => esc_html__( 'Special Feature Product Button Font Settings', 'hcode-addons' ),
      'group' => 'Feature Product Font & Color Settings',
      'description' => __( 'You can easily set button text-transform, font-size, line-height, letter-spacing for all devices ', 'hcode-addons' ),
      'hide_font_settings_element' => array( 'text-align', 'icon-color', 'icon-hover-color' ),
    ),
    $hcode_vc_extra_id,
    $hcode_vc_extra_class,
  )
) );